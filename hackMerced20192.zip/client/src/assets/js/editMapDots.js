export function renderDots(message, msgID){
    console.log("cool");
    console.log(msgID);
    console.log(message);
}