import React, { Component } from 'react';

//IMPORT COMPONENT
import Map from "./map";
import axios from 'axios';

class renderMapDots extends Component {
    render() { 
        return (
            <React.Fragment>
                <h1 className = "title">COOL</h1>
            </React.Fragment>
          );
    }
}
 
export default renderMapDots;