import React, { Component } from 'react';

class Messenger extends Component {
    state = {  }
    render() { 
        return (
            <React.Fragment>
                <h1>Current Coordinates:</h1>
            </React.Fragment>
          );
    }
}
 
export default Messenger;